# Simple ROS2 Node

This sample contains an example of how to use ROS2 in a backend. It takes the value from the analog output pin 0 and maps that to pin 1.

![PolyScope X Communication Application Node](tp.png)
