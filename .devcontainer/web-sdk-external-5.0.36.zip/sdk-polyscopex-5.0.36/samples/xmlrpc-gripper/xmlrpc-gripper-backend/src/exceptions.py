class ModbusNotInitialized(Exception):
    pass


class ModbusFailedWrite(Exception):
    pass


class ModbusFailedRead(Exception):
    pass
