# RTDE client library - Python
Library implements API for Universal Robots RTDE realtime interface.

Full description and implementation can be found on [github](https://github.com/UniversalRobots/RTDE_Python_Client_Library)

Full RTDE description is available on [Universal Robots support site](https://www.universal-robots.com/support/)